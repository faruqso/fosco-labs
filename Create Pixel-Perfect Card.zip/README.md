
  # Create Pixel-Perfect Card

  This is a code bundle for Create Pixel-Perfect Card. The original project is available at https://www.figma.com/design/gqqT12TcuLVsq0BWHvQyLt/Create-Pixel-Perfect-Card.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  